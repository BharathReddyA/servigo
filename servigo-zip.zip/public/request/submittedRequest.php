<html>
<body>

your service type is <?php echo $_POST["servicetype"]; ?><br>
Your email address is: <?php echo $_POST["landmark"]; ?>

</body>
</html>